#pragma once

// declare your functions and global variables here

char resultOfJudge[101];
int compileJudge();

int generateTestCaseJudge();

int compare();

void printResult();